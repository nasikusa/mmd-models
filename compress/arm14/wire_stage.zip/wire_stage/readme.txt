﻿wire_stage 

pmxを読み込んで使用してください。
ホワイト、ブルー、オレンジの三食があります。

拡大、縮小、AL、透過度、色変化に対応しています。


利用規約は付属のＵＲＬから確認をお願いします。

静画ページ : http://seiga.nicovideo.jp/user/illust/56180676
ウェブサイト : http://youkan.info

制作 : youkan(@nakanasinokusa)


